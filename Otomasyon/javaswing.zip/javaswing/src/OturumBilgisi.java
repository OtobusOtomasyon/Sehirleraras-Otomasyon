public class OturumBilgisi {
    public static String aktifKullaniciAdi;
}
